//
//  ViewController.swift
//  BeaconDetectorUIKit
//
//  Created by Hamza Mustafa on 15/02/2021.
//

import UIKit
import CoreLocation

class ViewController: UIViewController , CLLocationManagerDelegate {
    
    @IBOutlet weak var distanceReading: UILabel!
    var locationManger = CLLocationManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        locationManger.delegate = self
        locationManger.requestAlwaysAuthorization()
        view.backgroundColor = .gray
    }
    
    
    func locationManager(_ manager: CLLocationManager, didChangeAuthorization status: CLAuthorizationStatus) {
        switch status {
        case .restricted, .denied:
            // Disable your app's location features
            break
        case .authorizedWhenInUse:
            // Enable your app's location features.
            break
        case .authorizedAlways:
            // Enable or prepare your app's location features that can run any time.
            enableMyAlwaysFeatures()
            break
        case .notDetermined:
            break
        @unknown default:
            print("default")
        }
    }
    
    func enableMyAlwaysFeatures() {
        // Detects if beacon exist or not
        if CLLocationManager.isMonitoringAvailable(for: CLBeaconRegion.self) {
            // Detect how far away beacon is compare to us
            if CLLocationManager.isRangingAvailable(){
                startScanning()
            }
        }
    }
    
    func startScanning() {
        let uuid = UUID(uuidString: "B9407F30-F5F8-466E-AFF9-25556B57FE6D")!
        let beacons = CLBeaconIdentityConstraint(uuid: uuid)
        locationManger.startRangingBeacons(satisfying: beacons)
    }
    
    func update(message: String) {
        UIView.animate(withDuration: 1) {
            self.distanceReading.text = message
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didRange beacons: [CLBeacon], satisfying beaconConstraint: CLBeaconIdentityConstraint) {
        guard beacons.count > 0 else {
            UIView.animate(withDuration: 1) {
                self.update(message: "No Beacon Found")
                self.view.backgroundColor = UIColor.gray
            }
            return
        }
        
        let beacons = beacons.sorted { (b1, b2) -> Bool in
            b1.proximity.rawValue < b2.proximity.rawValue && b1.proximity.rawValue != -1
        }
        
        var message = ""
        print(beacons.count)
        for beacon in beacons {
            message = "\(message)Beacon Accuracy: \(self.getString(beacon.proximity))(\(Int(beacon.accuracy))), Minor: \(beacon.minor)\n"
        }
        
        UIView.animate(withDuration: 1) {
            self.update(message: message)
        }
    }
    
    func getString(_ string: CLProximity) -> String{
        switch string {
        case .far:
            return "Far"
        case .immediate:
            return "immediate"
        case .near:
            return "Near"
        case .unknown:
            return "UnKnown"
        default:
            return "UnKnown"
        }
    }
    
    func locationManager(_ manager: CLLocationManager, didEnterRegion region: CLRegion) {
        print(region.identifier)
    }
    
    func locationManager(_ manager: CLLocationManager, didExitRegion region: CLRegion) {
        print(region.identifier)
    }
}
